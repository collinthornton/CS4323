TO COMPILE
    ALL FILES (SRC AND INCLUDE) SHOULD BE IN SAME DIRECTORY

    gcc employee_record.c main.c -o main