COMPILATION INSTRUCTIONS

gcc msg.c process.c background.c clientServerEV.c server.c client.c main.c -lpthread -lrt -o main

OR

./compile.sh

-- BOTH OF THESE REQUIRE THAT ALL INCLUDE FILES ARE LOCATED IN THE pa2/include DIRECTORY --
-- BOTH OF THESE REQUIRE THAT ALL SRC FILES ARE LOCATED IN THE pa2/src DIRECTORY         --


EXECUTION INSTRUCTIONS

./main